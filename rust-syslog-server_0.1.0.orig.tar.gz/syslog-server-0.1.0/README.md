# Syslog-Server
A small automation project to set up a syslog server, which also serves as a playground for Rust.
