use std::fs; // Für Dateisystem-Operationen 
use std::io::{self, Write}; // Für Terminal IO

pub fn config_server() {
	// TODO: andere Skripte verbinden
	println!("[?] ");

}
