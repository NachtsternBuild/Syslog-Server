pub mod change_boot_menu;
pub mod config_server;
pub mod desktop_install_menu;
pub mod firewall_menu;
pub mod get_rsyslog_config;
